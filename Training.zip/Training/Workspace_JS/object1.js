let employee={
eid:1001,
"e name":"rajnikanth",
}
console.log(employee["e name"]);