let m1=45;
let m2=60;
let m3=70;
let m4=85;
let m5=60;
let m6=70;
let percentage=(m1+m2+m3+m4+m5+m6)/6*100;
if(percentage>45){
console.log('pass');
}
else if(percentage>70){
console.log('firstclass');}
else if(percentage>85)
{
console.log('distinction');
}