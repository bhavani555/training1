let king='jayant'
if(true){
let king="Ram"
console.log(king);
}
console.log(king)