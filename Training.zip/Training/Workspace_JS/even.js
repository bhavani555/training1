let x=11;
if(x%2==0){
console.log('even')}
else{
console.log('odd')
}

var num=10;
var result=(10%2)==0?'Even':'Odd';
console.log(result)
