if(true){
king="Ram"
console.log(king);
}
console.log(king)