console.log('Hello JavaScript');
let basic='1000'
let hra='2000'
let bonus='5000'
let salary=basic+hra+bonus;
console.log('salary')
console.log(salary)
let x=10
console.log(x)
let x=20
console.log(x)

