var king='jayant'
{
let king="Ram"
console.log(king);
}
console.log(king)