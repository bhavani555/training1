function breakfast(favFood='Oats'){
console.log(`I love ${favFood} in breakfast`)
console.log('I love'+favFood+' in breakfast')
}
breakfast('Maggie')
breakfast()


