let person={
name:"ABC",
age:30,
};
let clone=Object.assign({},person);
console.log(clone)