function greet(){
alert("Hello India");
}
greet()