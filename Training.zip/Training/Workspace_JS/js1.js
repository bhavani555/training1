var king='jayant'
{
var king="Ram"
console.log(king);
}
console.log(king)