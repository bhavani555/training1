let fname='jayanth';
let lname='surya';
let fullname=fname+''+lname;
console.log(fullname);

fname='jeevan';
console.log(fullname);