let employee={
eid:1001,
ename:"rajnikanth",
}
console.log(employee.ename);

let duplicateEmp={ename:"ABC"};
for(let key in employee){
duplicateEmp[key]=employee[key]

}
console.log(duplicateEmp.ename);