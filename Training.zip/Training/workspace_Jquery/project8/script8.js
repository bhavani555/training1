$(function() {


	$("p:first").css("background-color","red");

	$("li:first").css("background-color","rgba(180,180,30,.8)");

	$("input").css("background-color","red");

});