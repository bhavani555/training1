$(function() {

$(".red-box").hide(4000);
$(".red-box").show(4000);


});