$(function() {

$(".red-box").fadeTo(4000,0.2);
$(".green-box").fadeToggle(4000);

$(".green-box").fadeToggle(4000);
});