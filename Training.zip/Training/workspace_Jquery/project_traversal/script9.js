$(function() {


	$("#list").find("li").css("background-color","rgba(180,180,30,0.8)");

	
});