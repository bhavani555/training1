$(function() {

	//$("li li:first").replaceWith("<li>Replaced List</li>");

	//$("li").replaceWith("<li>Replaced List</li>");

	//$(".red-box").replaceWith($(".blue-box"));

	//$("li").replaceWith("<p>Replaced List</p>");
	//$(".red-box,.green-box").replaceWith($(".blue-box"));

//$("<div class='.red-box'></div>").replaceAll($(".green-box,.blue-box"));

//$("li").remove();
	//$("form").children().not("input:text,textarea,br").remove();
//$("form").children().not("input:text,textarea,br").detach();

/*var detachedElement=$("li").detach();
$("#content").append(detachedElement);*/

//$("p:first").empty();

/*var mylink=$("#mylink");
console.log(mylink.attr("href"))
mylink.attr("href","http://www.google.com");
console.log(mylink.attr("href"))*/


/*var textInput=$("input:text")
textInput.val("bhavani");
var rangeInput=$("input[type='range']")
console.log(textInput.val());
console.log(rangeInput.val());*/

var redbox=$(".red-box");
//console.log(redbox.css('width'));
//console.log(redbox.width());

//redbox.css("background-color","#AA7700");
redbox.css("user-select",function(){
return "none";
});

});