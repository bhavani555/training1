$(function() {


	//$("ul ul:first").append("<li>I love india</li>");

	//$("ul ul:last").append("<li>I love india</li>");
	//$("ul ul:first").prepend("<li>I love india</li>");
	//$("<li>2019 world champion</li>").prependTo($("ul ul:first"));
	//$("<li>2019 world champion</li>").appendTo($("ul ul:first"));
	
	//$("<li>2019 world champion</li>").prependTo($("ul ul"));
	//$("<h2>2019 world champion</h2>").prependTo($("#content"));
	//$("<p>2019 world champion</p>").prependTo($(".red-box"));

	//$(".red-box").after("<div class='red-box'>jadeja</div>");

	//$(".green-box").before("<div class='green-box'>jadeja</div>");
/*
$(".blue-box").after(function(){
return "<div class='blue-box'>jadeja</div>"
});
*/

	$(".red-box").after($(".blue-box"));




});