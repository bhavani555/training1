$(function() {
$(".red-box").fadeOut("slow");
$(".green-box").fadeOut("slow");
$(".red-box").fadeIn("slow");
});