$(function() {

$("h1").slideUp(2000);
$("h1").slideDown(2000);
$(".red-box").delay(2000).fadeOut(4000);

$(".green-box").delay(4000).fadeOut(5000);
$(".blue-box").delay(8000).fadeOut(5000);


});