$(function() {

$(".red-box").slideUp();
$(".red-box").slideDown();
$(".green-box").slideUp();
$(".green-box").slideDown();
$(".blue-box").slideUp();
$(".blue-box").slideDown();

});