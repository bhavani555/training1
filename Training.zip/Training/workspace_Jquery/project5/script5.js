$(function() {

$(".red-box").animate(
	{
	"margin-left":"200px",
	"width":"20px",
	"height":"20px",
	"opacity":"0.2",
	"margin-top":"50px"

	},4000,"swing"
 );

$(".green-box").animate(
	{
	"margin-left":"200px"
	},4000,"swing"
);


$("p").animate(
{
"font-size":"20px",
},"linear"
);
});