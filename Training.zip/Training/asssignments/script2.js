
function validation(){

let name= document.myform.name.value;
var pass1=document.myform.pass1.value;
var pass2=document.myform.pass2.value;


if(name==null||name==""){
alert("please enter name")
return false;
}



else if(pass1==pass2){
return true;
}
else{
alert("password must match")



}
}

$(function() {



$("input:even").css("background-color"," #D2D2D2");


$("body").css("color","Navy");

//$("h1").toggle(1000);
//$("h1").toggle(1000);
 $("h1:first").css("background-color", "yellow");

});