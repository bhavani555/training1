$(function() {



$("input:even").css("background-color"," #D2D2D2");
$("input:odd").css("background-color","cyan");

$("body").css("color","Navy");


 $("h1:first").css("background-color", "yellow");



});