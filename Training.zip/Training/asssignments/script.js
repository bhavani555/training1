function validation(){
var name=document.myform.name.value;
var password=document.myform.password.value;

if(name==null||name==""){
alert("please enter name")
return false;
}

else if(password.length<6){
alert("password should contain 6 characterstics")
return false;
}

var e=document.getElementById("sel");
var options=e.options[e.selectedIndex].value;

if(options=="admin")
{
window.open("homepage.html");
}
else if(options=="student")
{
 window.open("homepage-stu.html");
}
else{
alert("please select");
}
}

$(function() {



$("input").css("background-color"," #D2D2D2");
$("label").css("color","Navy");

$("#li").mouseenter(function(){
    $("#li").css("background-color", "yellow");
$("#li").mouseleave(function(){
      $("#li").css("background-color", "lightblue");
})
})

$("#foot").animate(
{
"font-size":"30px",
},"linear"
);
});