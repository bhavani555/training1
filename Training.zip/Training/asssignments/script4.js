$(function() {



$("input:even").css("background-color"," #D2D2D2");


$("body").css("color","Navy");

//$("h1").toggle(1000);
//$("h1").toggle(1000);
 $("h1:first").css("background-color", "yellow");

});